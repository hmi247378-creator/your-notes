DELETE FROM ChangeLog;
DELETE FROM ClassificationFeedback;
DELETE FROM ClassificationSuggestion;
DELETE FROM NoteTag;
DELETE FROM Note;
DELETE FROM IngestBatch;
DELETE FROM Tag;
DELETE FROM User;
